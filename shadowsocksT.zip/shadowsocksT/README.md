Removed according to regulations.
